package com.springeurekaclientdemo.SpringEurekaClientDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringEurekaClientDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
