package com.springeurekademo.SpringEurekaServiceDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringEurekaServiceDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringEurekaServiceDemoApplication.class, args);
	}

}
