package com.springeurekademo.SpringEurekaServiceDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringEurekaServiceDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
